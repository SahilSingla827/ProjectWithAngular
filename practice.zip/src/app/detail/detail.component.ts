import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../Employee';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  @Input() public parentarr:Employee[];

  constructor(private app: AppComponent){
  }
  ngOnInit(): void {
    this.sortByName();
  }
  sortByName(){
    this.parentarr = <Employee[]>this.app.arr.concat();
    this.parentarr.sort((a,b)=>a.name.localeCompare(b.name));
    console.log(this.parentarr);
    // for(var i=0;i<this.parentarr.length-1;i++)
    // {
    //   for(var j=0;j<this.parentarr.length-i-1;j++)
    //   {
    //     if(this.parentarr[j].name>this.parentarr[j+1].name)
    //     {
    //       var temp;
    //       temp=this.parentarr[j];
    //       this.parentarr[j]=this.parentarr[j+1];
    //       this.parentarr[j+1]=temp;
    //     }
    //   }
    //   this.flag=true;
    // }
    // console.log(this.parentarr)
  }
}
