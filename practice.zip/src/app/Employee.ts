export class Employee{
    id:number;
    name:string;
    age:number;
    constructor(id,name,age)
    {
        this.id=id;
        this.name=name;
        this.age=age;
    }
}