import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../Employee';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  @Input() public parentarr:Employee[];
  constructor(private app: AppComponent){
  }
  ngOnInit(): void {
    this.sortById();
  }
  sortById(){
    this.parentarr = <Employee[]>this.app.arr.concat();
    this.parentarr.sort((a,b)=>a.id-b.id);
    // for(var i=0;i<this.parentarr.length-1;i++)
    // {
    //   for(var j=0;j<this.parentarr.length-i-1;j++)
    //   {
    //     if(this.parentarr[j].id>this.parentarr[j+1].id)
    //     {
    //       var temp;
    //       temp=this.parentarr[j];
    //       this.parentarr[j]=this.parentarr[j+1];
    //       this.parentarr[j+1]=temp;
    //     }
    //   }
    // }
    // console.log(this.parentarr)
  }
}
