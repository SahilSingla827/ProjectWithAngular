import { Component, OnInit } from '@angular/core';
import { EmpService } from './emp.service';
import { Employee } from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'practice';
  public addflag:boolean=false;
  public arr:any[]=[];
  public id:Number;
  public name:string;
  public age:Number;
  obj:Employee;
  public sortbyid:boolean=false;
  public sortbyname:boolean=false;
  constructor(private empserv:EmpService){}
  ngOnInit()
  {
    this.empserv.getEmployee().subscribe(data=>this.arr=data);
  }
  public add()
  {
    this.addflag=true;
  }
  addEmp()
  {
    this.addflag=false;
    this.obj=new Employee(this.id,this.name,this.age);
    this.arr.push(this.obj);
  }
  remove(emp:Employee)
  {
    for(var i=0;i<this.arr.length;i++)
    {
      if(emp.id==this.arr[i].id)
      {
        this.arr.splice(i,1);
      }
    }
  }
  sortById()
  {
    this.sortbyid=true;
  }
  sortByName()
  {
    this.sortbyid=true;
  }
  
  
}
