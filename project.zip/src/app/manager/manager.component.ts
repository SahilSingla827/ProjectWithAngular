import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../Leave';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  //Attributes
  public empId:number;
  public empName:string;
  public userName:string;
  public selfEmpId:number;
  public leaveId:number;
  public reason:string;
  public oldPassword:string;
  public newPassword:string;

  //Flags
  //------1
  public searchEmploeeUsingIdFlag:boolean=false;
  public displaySearchEmploeeUsingIdArrFlag:boolean=false;

  //------2
  public searchEmploeeUsingNameFlag:boolean=false;
  public displaySearchEmploeeUsingNameArrFlag:boolean=false;

  //------3
  public displaySelfDetailsFlag:boolean=false;

  //------4
  public displayAllSubordinatesFlag=false;

  //------5
  public displayAllLeavesOfSubordinatesFlag=false;

  //------6
  public acceptLeaveFlag=false;
  public successAcceptLeaveFlag=false;
  public failureAcceptLeaveFlag=false;

  //------7
  public rejectLeaveFlag=false;
  public successRejectLeaveFlag=false;
  public failureRejectLeaveFlag=false;

  //------8
  public changeAccountPasswordFlag=false;
  public successInChangingAccountPasswordFlag=false;
  public failureInChangingAccountPasswordFlag=false;

  //Arrays

  //------1
  public searchEmploeeUsingIdArr:Employee[]=[];
  public displaySearchEmploeeUsingIdArr:Employee[]=[];

  //------2
  public searchEmploeeUsingNameArr:Employee[]=[];
  public displaySearchEmploeeUsingNameArr:Employee[]=[];

  //------3
  public findSelfDetailsArr:Login[]=[];
  public allEmpDetailsArr:Employee[]=[];
  public displaySelfDetailsArr:Employee[]=[];

  //------4
  public displayAllSubordinatesArr:Employee[]=[];

  //------5
  public displayAllLeavesOfSubordinatesArr:Leave[]=[];
  public allEmpLeavesArr:Leave[]=[];

  //------6
  public findAllSubordinatesLeavesArr:Leave[]=[];
  
  //------8
  public loginArr:Login[]=[];


  //<<<<<<<<<<-------------Constructor------------------>>>>>>>>
  constructor(private empService:EmployeeService,private appComponent:AppComponent,private router:Router) { }

  ngOnInit(): void {
  }
//<<<<<<<<<<-------------1st Functionality------------------>>>>>>>>

//To display the table for taking input from user
  public searchEmploeeUsingId()
  {
    this.searchEmploeeUsingIdFlag=true;
  }

//To remove table of taking input from the screen and display the result on to the screen
  public startSearchingEmployeeUsingId()
  {
    this.searchEmploeeUsingIdFlag=false;
    this.searchEmploeeUsingIdArr=this.empService.empArr;
    //To find the employee with the particular Id
    for(var i=0;i<this.searchEmploeeUsingIdArr.length;i++)
    {
      if(this.searchEmploeeUsingIdArr[i].empId===this.empId)
      {
        this.displaySearchEmploeeUsingIdArr.push(this.searchEmploeeUsingIdArr[i]);
      }
    }
    this.displaySearchEmploeeUsingIdArrFlag=true;
  }
  //Removing the result Table from screen
  public closeDisplaySearchEmploeeUsingIdArr()
  {
    this.empId=null;
    this.displaySearchEmploeeUsingIdArr=[];
    this.displaySearchEmploeeUsingIdArrFlag=false;
  }

  //<<<<<<<<<<-------------2nd Functionality------------------>>>>>>>>

  //To display the table for taking input from user
  public searchEmploeeUsingName()
  {
    this.searchEmploeeUsingNameFlag=true;
  }

  //To remove table of taking input from the screen and display the result on to the screen
  public startSearchingEmployeeUsingName()
  {
    this.searchEmploeeUsingNameFlag=false;
    this.searchEmploeeUsingNameArr=this.empService.empArr;
    //To find employees with paricular name
    for(var i=0;i<this.searchEmploeeUsingNameArr.length;i++)
    {
      if(this.searchEmploeeUsingNameArr[i].empName.localeCompare(this.empName)==0)
      {
        this.displaySearchEmploeeUsingNameArr.push(this.searchEmploeeUsingNameArr[i]);
      }
    }
    this.displaySearchEmploeeUsingNameArrFlag=true;
  }

  //Removing the result Table from screen
  public closeDisplaySearchEmploeeUsingNameArr()
  {
    this.empName="";
    this.displaySearchEmploeeUsingNameArr=[];
    this.displaySearchEmploeeUsingNameArrFlag=false;
  }

//<<<<<<<<<<-------------3rd Functionality------------------>>>>>>>>

//find empid from username and then using that empid find all the details and display result on screen
public findSelfDetails()
{
  this.userName=this.appComponent.userName;
  this.findSelfDetailsArr=this.empService.loginArr;
  this.allEmpDetailsArr=this.empService.empArr;
  //To find the empId
  for(var i=0;i<this.findSelfDetailsArr.length;i++)
  {
    if(this.findSelfDetailsArr[i].userName.localeCompare(this.userName)==0)
    {
      this.selfEmpId=this.findSelfDetailsArr[i].empId;
      break;
    }
  }
  //To find particular details that belongs to the Id
  for(var j=0;j<this.allEmpDetailsArr.length;j++)
  {
    if(this.allEmpDetailsArr[j].empId===this.selfEmpId)
    {
      this.displaySelfDetailsArr.push(this.allEmpDetailsArr[j]);
      break;
    }
  }
  this.displaySelfDetailsFlag=true;
}
//Removing the result Table from screen
public closeDisplaySelfDetails()
{
  this.displaySelfDetailsArr=[];
  this.displaySelfDetailsFlag=false;
}


//<<<<<<<<<<-------------4th Functionality------------------>>>>>>>>

//finding the managers empId and using that find all its subordinates and display them on to the screen
public findAllSubordinates()
{
  this.userName=this.appComponent.userName;
  this.findSelfDetailsArr=this.empService.loginArr;
  this.allEmpDetailsArr=this.empService.empArr;
  //To find empId of Manager
  for(var i=0;i<this.findSelfDetailsArr.length;i++)
  {
    if(this.findSelfDetailsArr[i].userName.localeCompare(this.userName)==0)
    {
      this.selfEmpId=this.findSelfDetailsArr[i].empId;
      break;
    }
  }
  //To find subordinates using managerId
  for(var j=0;j<this.allEmpDetailsArr.length;j++)
  {
    if(this.allEmpDetailsArr[j].managerId===this.selfEmpId && this.allEmpDetailsArr[j].empId!=this.selfEmpId)
    {
      this.displayAllSubordinatesArr.push(this.allEmpDetailsArr[j]);
    }
  }
  this.displayAllSubordinatesFlag=true;
}
//Removing the result Table from screen
public closeDisplayAllSubordinatesArr()
{
  this.displayAllSubordinatesArr=[];
  this.displayAllSubordinatesFlag=false;
}


//<<<<<<<<<<-------------5th Functionality------------------>>>>>>>>

//Finding out the empId of the manager and using that finding out all the leaves of the subordinates
//and displaying the leaves on to the screen
public findAllLeavesOfSubordinates()
{
  this.userName=this.appComponent.userName;
  this.findSelfDetailsArr=this.empService.loginArr;
  this.allEmpLeavesArr=this.empService.leaveArr;
  //To find empId of the Manager
  for(var i=0;i<this.findSelfDetailsArr.length;i++)
  {
    if(this.findSelfDetailsArr[i].userName.localeCompare(this.userName)==0)
    {
      this.selfEmpId=this.findSelfDetailsArr[i].empId;
      break;
    }
  }
  //To find leaves applied by subordinates and in pending status
  for(var j=0;j<this.allEmpLeavesArr.length;j++)
  {
    if(this.allEmpLeavesArr[j].managerId===this.selfEmpId && this.allEmpLeavesArr[j].empId!=this.selfEmpId && this.allEmpLeavesArr[j].status.localeCompare("pending")==0)
    {
      this.displayAllLeavesOfSubordinatesArr.push(this.allEmpLeavesArr[j]);
    }
  }
  this.displayAllLeavesOfSubordinatesFlag=true;
}

//Removing the result Table from screen
public closeDisplayAllLeavesOfSubordinatesArr()
{
  this.displayAllLeavesOfSubordinatesArr=[];
  this.displayAllLeavesOfSubordinatesFlag=false;
}

//<<<<<<<<<<-------------6th Functionality------------------>>>>>>>>

//To display the table for taking leaveId as input from the manager
public acceptLeave()
{
  this.acceptLeaveFlag=true;
}

//To accept the leaves that belongs to the subordinates and are in pending status
public startAcceptLeave():number
{
  this.userName=this.appComponent.userName;
  this.findSelfDetailsArr=this.empService.loginArr;
  this.allEmpLeavesArr=this.empService.leaveArr;
  //To find managerId
  for(var i=0;i<this.findSelfDetailsArr.length;i++)
  {
    if(this.findSelfDetailsArr[i].userName.localeCompare(this.userName)==0)
    {
      this.selfEmpId=this.findSelfDetailsArr[i].empId;
      break;
    }
  }
  //To find subordinates leaves
  for(var j=0;j<this.allEmpLeavesArr.length;j++)
  {
    if(this.allEmpLeavesArr[j].managerId===this.selfEmpId && this.allEmpLeavesArr[j].empId!=this.selfEmpId)
    {
      this.findAllSubordinatesLeavesArr.push(this.allEmpLeavesArr[j]);
    }
  }
  //To accept particular leave and set status of the leave to reviewed
  for(var k=0;k<this.findAllSubordinatesLeavesArr.length;k++)
  {
    if(this.findAllSubordinatesLeavesArr[k].leaveId==this.leaveId && this.findAllSubordinatesLeavesArr[k].status.localeCompare("pending")==0)
    {
      this.empService.decreaseLeaveCount(this.findAllSubordinatesLeavesArr[k].empId);
      this.findAllSubordinatesLeavesArr[k].status="reviewed";
      this.acceptLeaveFlag=false;
      this.successAcceptLeaveFlag=true;
      return 0;
    }
  }
  this.acceptLeaveFlag=false;
  this.failureAcceptLeaveFlag=true;
}

// Remove the accepted result from the screen
public closeSuccessAcceptLeave()
{
  this.leaveId=null;
  this.successAcceptLeaveFlag=false;
}
// To Remove the result from the screen
public closeFailureAcceptLeave()
{
  this.leaveId=null;
  this.failureAcceptLeaveFlag=false;
}

//<<<<<<<<<<-------------7th Functionality------------------>>>>>>>>

//To display the table for taking leaveId and reason as input from the manager
public rejectLeave()
{
  this.rejectLeaveFlag=true;
}

//To reject the leaves that belongs to the subordinates and are in pending status
public startRejectLeave()
{
  this.userName=this.appComponent.userName;
  this.findSelfDetailsArr=this.empService.loginArr;
  this.allEmpLeavesArr=this.empService.leaveArr;
  //finding empId of the manager from userName
  for(var i=0;i<this.findSelfDetailsArr.length;i++)
  {
    if(this.findSelfDetailsArr[i].userName.localeCompare(this.userName)==0)
    {
      this.selfEmpId=this.findSelfDetailsArr[i].empId;
      break;
    }
  }
  //Finding out the leaves of subordinates
  for(var j=0;j<this.allEmpLeavesArr.length;j++)
  {
    if(this.allEmpLeavesArr[j].managerId===this.selfEmpId && this.allEmpLeavesArr[j].empId!=this.selfEmpId)
    {
      this.findAllSubordinatesLeavesArr.push(this.allEmpLeavesArr[j]);
    }
  }
  //To reach to the particular leave and set its status to reviewed
  for(var k=0;k<this.findAllSubordinatesLeavesArr.length;k++)
  {
    if(this.findAllSubordinatesLeavesArr[k].leaveId==this.leaveId && this.findAllSubordinatesLeavesArr[k].status.localeCompare("pending")==0)
    {
      this.findAllSubordinatesLeavesArr[k].status="reviewed";
      this.rejectLeaveFlag=false;
      this.successRejectLeaveFlag=true;
      return 0;
    }
  }
  this.rejectLeaveFlag=false;
  this.failureRejectLeaveFlag=true;
}

// To Remove the result of successful rejectance from the screen
public closeSuccessRejectLeave()
{
  this.leaveId=null;
  this.reason="";
  this.successRejectLeaveFlag=false;
}

// To Remove the result from the screen
public closeFailureRejectLeave()
{
  this.leaveId=null;
  this.reason="";
  this.failureRejectLeaveFlag=false;
}

//<<<<<<<<<<-------------8th Functionality------------------>>>>>>>>

//To show thw table for taking input from user on to the screen
public changeAccountPassword()
{
  this.changeAccountPasswordFlag=true;
}

//To match the olsd password from the one in database and then show the result correspondingly on to the screen
public startChangingAccountPassword():number
{
  this.loginArr=this.empService.loginArr;
  //To match old password with database and show result correspondingly
  for(var i=0;i<this.loginArr.length;i++)
  {
    if(this.loginArr[i].userName.localeCompare(this.appComponent.userName)==0)
    {
      if(this.loginArr[i].password.localeCompare(this.oldPassword)==0)
      {
        this.empService.changePassword(this.loginArr[i].userName,this.newPassword);
        this.changeAccountPasswordFlag=false;
        this.successInChangingAccountPasswordFlag=true;
        return 1;
      }
    }
  }
  this.changeAccountPasswordFlag=false;
  this.failureInChangingAccountPasswordFlag=true;
  return 0;
}

//To remove the result from the screen
public closeSuccessInChangingAccountPassword()
{
  this.oldPassword="";
  this.newPassword="";
  this.successInChangingAccountPasswordFlag=false;
}

//To remove the result from the screen
public closeFailureInChangingAccountPassword()
{
  this.oldPassword="";
  this.newPassword="";
  this.failureInChangingAccountPasswordFlag=false;
}


//<<<<<<<<<<-------------9th Functionality------------------>>>>>>>>

//To logout
public logOut()
{
  this.appComponent.loginFlag=false;
  this.appComponent.userName="";
  this.appComponent.password="";
  this.router.navigate(['/..']);
}
}