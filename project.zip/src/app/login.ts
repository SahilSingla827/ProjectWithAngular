export class Login{
    userName:string;
    loginType:string;
    password:string;
    empid:number;

    constructor(userName,loginType,password,empid)
    {
        this.userName=userName;
        this.loginType=loginType;
        this.password=password;
        this.empid=empid;
    }

}