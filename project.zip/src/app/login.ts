export class Login{
    userName:string;
    loginType:string;
    password:string;
    empId:number;

    constructor(userName,loginType,password,empId)
    {
        this.userName=userName;
        this.loginType=loginType;
        this.password=password;
        this.empId=empId;
    }

}