export class Leave{
    leaveId:number;
    fromDate:Date;
    toDate:Date;
    appliedDate:Date;
    empId:number;
    managerId:number;
    reason:string;
    status:string;

    constructor(leaveId,fromDate,toDate,appliedDate,empId,managerId,reason)
    {
        this.leaveId=leaveId;
        this.fromDate=fromDate;
        this.toDate=toDate;
        this.appliedDate=appliedDate;
        this.empId=empId;
        this.managerId=managerId;
        this.reason=reason;
        this.status="pending";
    }
}