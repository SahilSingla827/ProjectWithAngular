import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Login } from './login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'project';
  
  public loginArr:Login[]=[];
  public userName:string;
  public password:string;
  public loginFlag:boolean=false;
  public adminFlag:boolean=false;
  public managerFlag:boolean=false;
  public employeeFlag:boolean=false;
  constructor(private empservice:EmployeeService,private router:Router){}
  ngOnInit()
  {
    
  }
  public authenticate()
  {
    this.loginArr=this.empservice.loginArr;
    for(var i=0;i<this.loginArr.length;i++)
    {
      if(this.loginArr[i].userName.localeCompare(this.userName)==0 && this.loginArr[i].password.localeCompare(this.password)==0)
      {
        this.loginFlag=true;
        if(this.loginArr[i].loginType.localeCompare('admin')==0)
        {
          this.adminFlag=true;
          this.router.navigate(['/admin']);
        }
        if(this.loginArr[i].loginType.localeCompare('manager')==0)
        {
          this.managerFlag=true;
          this.router.navigate(['/manager']);
        }
        if(this.loginArr[i].loginType.localeCompare('employee')==0)
        {
          this.employeeFlag=true;
          this.router.navigate(['/employee']);
        }
      }
    }
  }
}
