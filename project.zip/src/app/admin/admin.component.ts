import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
import { Login } from '../login';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

//-------Arrays-----------
  public dispEmpArr:Employee[]=[];
  public empArrSearchById:Employee[]=[];
  public empArrSearchByName:Employee[]=[];

  public displaySearchById:Employee[]=[];
  public displaySearchByName:Employee[]=[];
  public loginArr:Login[]=[];

  public employee:Employee[]=[];

//-----------Flags--------

//------1
  public addEmpFlag=false;
  public showSuccessAddEmpResultFlag:boolean=false;
  public showFailureAddEmpResultFlag:boolean=false;

//------2
  public deleteEmpFlag=false;
  public showDeleteResponseFlag=false;

//------3
  public modifyEmpFlag=false;
  public displayModifyEmpPreviousDetailsFlag=false;
  public showModifyEmpResponseFlag=false;

//------4
  public searchByIdFlag=false;
  public searchByIdResultFlag=false;
  public searchByIdNotFindFlag=false;
  
//------5
  public searchByNameFlag=false;
  public searchByNameResultFlag=false;
  public displayNoEmployeeFoundFlag=false;

//------6
  public displayAllEmpFlag=false;
  
//------7
  public changePasswordFlag=false;
  public successfullyChangedPasswordFlag=false;
  public failureChangePasswordFlag=false;
  

//-----------Attributes----------
  public empName:string;
  public empId:number;
  public empSalary:number;
  public deptId:number;
  public dob:Date;
  public contactNumber:number;
  public managerId:number;
  public numberOfLeavesLeft:number;
  public designation:string;

  public oldPassword:string;
  public newPassword:string;

  public empToDelete:number;

  public emp:Employee=null;
  
//----------constructor---------
  constructor(private empserv:EmployeeService,private app:AppComponent,private router:Router) { }

  ngOnInit(): void {
  }

//<<<<<<----------------------1st Functionality------------------->>>>>>>>

//To display the table of taking input from user
  public addEmployee():void
  {
    this.empId=null;
    this.empName="";
    this.empSalary=null;
    this.deptId=null;
    this.dob=null;
    this.contactNumber=null;
    this.managerId=null;
    this.numberOfLeavesLeft=null;
    this.designation="";
    this.addEmpFlag=true;
  }

//To add the employee to the database
  public startAddingEmployee():number
  {
    this.addEmpFlag=false;
    this.emp=new Employee(this.empName,this.empId,this.empSalary,this.deptId,this.dob,this.contactNumber,this.managerId,this.numberOfLeavesLeft,this.designation);
    for(var i=0;i<this.empserv.empArr.length;i++)
    {
      if(this.empserv.empArr[i].empId===this.emp.empId)
      {
        this.showFailureAddEmpResultFlag=true;
        return 1;
      }
    }
    this.empserv.addNewEmp(this.emp);
    this.showSuccessAddEmpResultFlag=true;
    return 0;
  }

//To remove the result from the screen
  public closeShowSuccessAddEmpResult()
  {
    this.showSuccessAddEmpResultFlag=false;
  }

  //To remove the result from the screen
  public closeShowFailureAddEmpResult()
  {
    this.showFailureAddEmpResultFlag=false;
  }


//<<<<<<----------------------2nd Functionality------------------->>>>>>>>

//To show the input table on to the screen
  public deleteEmployee()
  {
    this.deleteEmpFlag=true;
  }

//To delete the result from database and show result on the screen
  public startDeletingEmployee()
  {
    this.empserv.deleteEmployee(this.empToDelete);
    this.deleteEmpFlag=false;
    this.showDeleteResponseFlag=true;
  }

//To remove the result table from the screen
  public closeShowDeleteResponse()
  {
    this.showDeleteResponseFlag=false;
  }

//<<<<<<----------------------3rd Functionality------------------->>>>>>>>

//To show the table for taking input onto the screen
  public modifyEmployee()
  {
    this.empId=null;
    this.empName="";
    this.empSalary=null;
    this.deptId=null;
    this.dob=null;
    this.contactNumber=null;
    this.managerId=null;
    this.numberOfLeavesLeft=null;
    this.designation="";
    this.modifyEmpFlag=true;
  }

//To set the details from database into the table
  public setDetails()
  {
    this.modifyEmpFlag=false;
    this.employee=this.empserv.empArr;
    for(var i=0;i<this.employee.length;i++)
    {
      
      if(this.employee[i].empId===this.empId)
      {
        this.emp=this.employee[i];
        this.empName=this.emp.empName;
        this.empSalary=this.emp.empSalary;
        this.deptId=this.emp.deptId;
        this.dob=this.emp.dateofbirth;
        this.contactNumber=this.emp.contactNumber;
        this.managerId=this.emp.managerId;
        this.numberOfLeavesLeft=this.emp.numOfLeaves;
        this.designation=this.emp.designation;
        break;
      }
    }
    this.displayModifyEmpPreviousDetailsFlag=true;
  }

  //To update the newly entered details into the database
  public updateDetails()
  {
    this.emp=new Employee(this.empName,this.empId,this.empSalary,this.deptId,this.dob,this.contactNumber,this.managerId,this.numberOfLeavesLeft,this.designation);
    this.empserv.updateDetails(this.emp);
    this.displayModifyEmpPreviousDetailsFlag=false;
    this.showModifyEmpResponseFlag=true;
  }

  //To remove the response of modification from the screen
  public closeShowModifyEmpResponse()
  {
    this.empId=null;
    this.showModifyEmpResponseFlag=false;
  }


  //<<<<<<----------------------4th Functionality------------------->>>>>>>>

//To show the table for taking empid on to the screen
  public searchEmployeesById()
  {
    this.empId=null;
    this.searchByIdFlag=true;
  }

//To search For the particular employee and show the response on to the screen
  public startSearchingById()
  {
    this.searchByIdFlag=false;
    this.empArrSearchById=this.empserv.empArr;
    for(var i=0;i<this.empArrSearchById.length;i++)
    {
      if(this.empArrSearchById[i].empId===this.empId)
      {
        this.displaySearchById.push(this.empArrSearchById[i]);
      }
    }
    if(this.displaySearchById.length>0)
    {
      this.searchByIdResultFlag=true;
    }
    else
    {
      this.searchByIdNotFindFlag=true;
    }
    
  }

  //To remove the response output from the screen
  public closeSearchByIdResult()
  {
    this.searchByIdResultFlag=false;
    this.displaySearchById=[];
  }
  public closeSearchByIdNotFoundResult()
  {
    this.searchByIdNotFindFlag=false;
  }

  
  //<<<<<<----------------------5th Functionality------------------->>>>>>>>

  //To show the table for taking empName on to the screen
  public searchEmployeesByName()
  {
    this.empName="";
     this.searchByNameFlag=true;
  }

  //To search for the employees with that particular name and show the response on the screen
  public startSearchingByName()
  {
    
    this.searchByNameFlag=false;
    this.empArrSearchByName=this.empserv.empArr;
    for(var i=0;i<this.empArrSearchByName.length;i++)
    {
      if(this.empArrSearchByName[i].empName.localeCompare(this.empName)==0)
      {
        this.displaySearchByName.push(this.empArrSearchByName[i]);
      }
    }
    if(this.displaySearchByName.length>0)
    {
      this.searchByNameResultFlag=true;
    }
    else
    {
      this.displayNoEmployeeFoundFlag=true;
    }
     
  }

//To remove the response of searching an employee by name from the screen
  public closeSearchByNameResult()
  {
    this.searchByNameResultFlag=false;
    this.displaySearchByName=[];
  }
  public closeResultOfNoEmployeeFound()
  {
    this.displayNoEmployeeFoundFlag=false;
  }


  //<<<<<<----------------------6th Functionality------------------->>>>>>>>

  //To display all employees on to the screen
  public displayEmployees()
  {
    this.dispEmpArr=this.empserv.empArr;
    this.displayAllEmpFlag=true;
  }

  //To remove the table of all employees from the screen
  public closeDispEmpArr()
  {
    this.displayAllEmpFlag=false;
  }
  
//<<<<<<----------------------7th Functionality------------------->>>>>>>>

//To show the table for taking old and new password as input from the user
public changePassword()
{
  this.changePasswordFlag=true;
}

//To match old password with the one in database and show the result correspondingly
public setChangePasswordFlag():number
{
  this.loginArr=this.empserv.loginArr;
  
  for(var i=0;i<this.loginArr.length;i++)
  {
    if(this.loginArr[i].userName.localeCompare(this.app.userName)==0)
    {
      if(this.loginArr[i].password.localeCompare(this.oldPassword)==0)
      {
        this.empserv.changePassword(this.loginArr[i].userName,this.newPassword);
        this.successfullyChangedPasswordFlag=true;
        this.changePasswordFlag=false;
        return 1;
      }
    }
  }
  this.failureChangePasswordFlag=true;
  this.changePasswordFlag=false;
  return 0;
}

//To remove the response from screen of successful updation of password
public closeSuccessfullyChangedPassword()
{
  this.successfullyChangedPasswordFlag=false;
}

//To remove the response from screen of failure in updation of password
public closeFailureChangePassword()
{
  this.failureChangePasswordFlag=false;
}

//<<<<<<----------------------8th Functionality------------------->>>>>>>>

//To Logout
public logOut()
{
  this.app.loginFlag=false;
  this.app.userName="";
  this.app.password="";
  this.router.navigate(['/..']);
  
}
}
