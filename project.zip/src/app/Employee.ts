export class Employee{
    empName:string;
    empId:number;
    empSalary:number;
    deptId:number;
    dateofbirth:Date;
    contactNumber:number;
    managerId:number;
    numOfLeaves:number;
    designation:string;
  
    constructor(empName,empId,empSalary,deptId,dateofbirth,contactNumber,managerId,numOfLeaves,designation)
    {
        this.empName=empName;
        this.empId=empId;
        this.empSalary=empSalary;
        this.deptId=deptId;
        this.dateofbirth=dateofbirth;
        this.contactNumber=contactNumber;
        this.managerId=managerId;
        this.numOfLeaves=numOfLeaves;
        this.designation=designation;
    }
    // public setEmpName(name:string)
    // {
    //     this.empName=name;
    // }
    // public setEmpSalary(sal:number)
    // {
    //     this.empSalary=sal;
    // }
    // public setDeptId(depId:number)
    // {
    //     this.deptId=depId;
    // }
    // public setDob(birthDate:Date)
    // {
    //     this.dateofbirth=birthDate;
    // }
    // public setContactNumber(phnNum:number)
    // {
    //     this.contactNumber=phnNum;
    // }
    // public setManagerId(manId:number)
    // {
    //     this.managerId=manId;
    // }
    // public setNumberOfLeavesLeft(leavenum:number)
    // {
    //     this.numOfLeaves=leavenum;
    // }
    // public setDesignation(desig:string)
    // {
    //     this.designation=desig;
    // }


    // public fun():void
    // {
    //     console.log('saaaaddgdgd');
    // }
}