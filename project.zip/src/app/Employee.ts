export class Employee{
    empName:string;
    empId:number;
    empSalary:number;
    deptId:number;
    dob:Date;
    contactNumber:number;
    managerId:number;
    numberOfLeavesLeft:number;
    designation:string;
  
    constructor(empName,empId,empSalary,deptId,dob,contactNumber,managerId,numberOfLeavesLeft,designation)
    {
        this.empName=empName;
        this.empId=empId;
        this.empSalary=empSalary;
        this.deptId=deptId;
        this.dob=dob;
        this.contactNumber=contactNumber;
        this.managerId=managerId;
        this.numberOfLeavesLeft=numberOfLeavesLeft;
        this.designation=designation;
    }
}