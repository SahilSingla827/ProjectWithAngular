import { Injectable, OnInit } from '@angular/core';
import { Login } from './login';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './Employee';
import { Leave } from './Leave';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService implements OnInit {

  public loginUrl:string='./assets/login.json';
  public employeesUrl='./assets/employee.json';
  public leavesUrl='./assets/leave.json';

  public  empArr:Employee[]=[];
  public loginArr:Login[]=[];
  public leaveArr:Leave[]=[];

  public login:Login;
  
  constructor(private http:HttpClient) {
    this.getEmployeeDetails();
    this.getLoginDetails();
    this.getAllLeaves();
   }

  ngOnInit()
  {
    
  }
  public getLoginDetails()
  {
    this.http.get<Login[]>(this.loginUrl).subscribe(data=>this.loginArr=data);
  }

  public getEmployeeDetails()
  {
    this.http.get<Employee[]>(this.employeesUrl).subscribe(data=>this.empArr=data);
    
  }
  public getAllLeaves()
  {
    this.http.get<Leave[]>(this.leavesUrl).subscribe(data=>this.leaveArr=data);
  }
  public addNewEmp(emp:Employee):void
  {
    this.empArr.push(emp);
    
    this.login=new Login(emp.empName+emp.empId,emp.designation,emp.empName,emp.empId);
    this.loginArr.push(this.login);
  }
  public deleteEmployee(employeeId:number)
  {
    for(var i=0;i<this.empArr.length;i++)
    {
      if(this.empArr[i].empId==employeeId)
      {
        this.empArr.splice(i,1);
      }
    }
  }
  public updateDetails(emp:Employee)
  {
    for(var i=0;i<this.empArr.length;i++)
    {
      if(this.empArr[i].empId==emp.empId)
      {
        
        this.empArr[i].empName=emp.empName;
        this.empArr[i].empSalary=emp.empSalary;
        this.empArr[i].deptId=emp.deptId;
        this.empArr[i].dateofbirth=emp.dateofbirth;
        this.empArr[i].contactNumber=emp.contactNumber;
        this.empArr[i].managerId=emp.managerId;
        this.empArr[i].numOfLeaves=emp.numOfLeaves;
        this.empArr[i].designation=emp.designation;
      }
  }

}
public changePassword(userName:string,password:string)
{
  for(var i=0;i<this.loginArr.length;i++)
  {
    if(this.loginArr[i].userName.localeCompare(userName)==0)
    {
      this.loginArr[i].password=password;
    }
  }
}

public decreaseLeaveCount(empId:number)
{
  for(var i=0;i<this.empArr.length;i++)
  {
    if(this.empArr[i].empId===empId)
    {
      this.empArr[i].numOfLeaves=this.empArr[i].numOfLeaves-1;
    }
  }
}

}